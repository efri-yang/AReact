require('cp');

$(() => {
});
